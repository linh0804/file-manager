# [Adminer Design Dark]

![Preview](/preview.png "Preview")

**Tested** on MacOS Chrome only (sorry _:-)_), compatible with Adminer 4.8.0

## Changelog

2.0.1 - Minor fixes

2.0.0 - CSS variables, color unification, minor fixes

1.0.5 - Fix select box padding

1.0.4 - Custom checkboxes and radio button styles

1.0.3 - Lang selector position fixed
