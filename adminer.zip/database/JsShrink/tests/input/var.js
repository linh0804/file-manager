var a = 1; // simple assignment
