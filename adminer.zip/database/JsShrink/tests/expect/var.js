var
a=1;