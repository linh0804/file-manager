<?php

const ACCESS = 1;

require __DIR__ . '/../vendor/autoload.php';

function adminer_object()
{
    foreach (glob("plugins/*.php") as $filename) {
        include_once "./$filename";
    }
		
    return new AdminerPlugin([
        /*
        new AdminerDatabaseHide([
            'mysql',
            'information_schema',
            'performance_schema',
            'sys',
        ]),
        */
        new AdminerTheme("default-green"),
    ]);
}

require __DIR__ . '/adminer.php';
//require __DIR__ . '/adminer-4.8.1.php';
