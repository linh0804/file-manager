<?php
namespace app;

if (isset($_COOKIE['fm_php'])) {
    phpinfo();
}
