<?php

const ACCESS = true;
const DONT_LOAD_INI_SET = true;

require '.init.php';

phpinfo();
