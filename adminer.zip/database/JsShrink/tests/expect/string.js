var
s=' double '+' space ';