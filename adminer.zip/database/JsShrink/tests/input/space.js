function f(a) {
	return a;
	throw a;
	label:
	while (false) {
		break label;
	}
}
