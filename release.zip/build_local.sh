dir="/www/web/static/__dist__/php/file-manager"

cp -f install.txt "$dir/"
cp -f install.sh "$dir/"
cp -f install_termux.sh "$dir/"
cp -f version.json $dir/release.json
cp -f release.zip "$dir/"


