// start of file
/***/
/**/
var a = 1 / /* */ / .* / /**/ / / .* /;
