<?php
namespace app;

return [
    'hiddenDatabases' => '__system',
    'visibleCollations' => [
        "utf8mb4_general_ci",
        "utf8mb4_vietnamese_ci",
        "utf8mb4_uca1400_ai_ci"
    ]
];
