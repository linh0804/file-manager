<?php

if (isset($_COOKIE['fm_php'])) {
    phpinfo();
}
