<?php

const ACCESS = 1;
const LOGIN = 1;

require __DIR__ . '/../.init.php';

/*
$modules = file_get_contents(rootPath . '/vendor/ngatngay/php-database-admin/.gitmodules');
preg_match_all('/url\s*=\s*(https?:\/\/[^\s]+)/', $modules, $matches);

foreach ($matches[1] as $url) {
    passthru("git clone --depth 1 $url");
}
passthru("git clone --depth 1 https://github.com/pematon/adminer-theme");
*/
//exit;

@rmdir(rootPath . '/vendor/ngatngay/php-database-admin/externals/jush');
@symlink(__DIR__ . '/jush', rootPath . '/vendor/ngatngay/php-database-admin/externals/jush');

@rmdir(rootPath . '/vendor/ngatngay/php-database-admin/externals/JsShrink');
@symlink(__DIR__ . '/JsShrink', rootPath . '/vendor/ngatngay/php-database-admin/externals/JsShrink');



require rootPath . '/vendor/ngatngay/php-database-admin/compile.php';

rename($filename, 'adminer.php');
echo "{$filename} renamed to adminer.php.\n";

$file = __DIR__ . '/adminer.php';

$contents = file($file);
$contents[0] = "<?php defined('ACCESS') or exit('Not access');\n";

//file_put_contents($file, implode('', $contents));
