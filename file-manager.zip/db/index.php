<?php

isset($_COOKIE["fm_php"]) or exit;

error_reporting(0);
require 'admin';
